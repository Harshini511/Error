package com.example.demo.repository;

import com.example.demo.model.EntityData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EntityDataRepository extends JpaRepository<EntityData, Long> {

    public List<EntityData> findByEntityID(Long entityID);

}
