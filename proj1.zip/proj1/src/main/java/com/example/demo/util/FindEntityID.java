package com.example.demo.util;

import com.example.demo.model.Index;
import com.example.demo.repository.IndexRepository;

import java.util.List;

public class FindEntityID {

    public static Long byName(String entityName, IndexRepository indexRepo) {
        Long entityID = Long.MAX_VALUE;
        List<Index> listOfEntityIndex = indexRepo.findByEntityName(entityName);
        if(listOfEntityIndex.size() != 0) {
            entityID = listOfEntityIndex.get(0).getEntityID();
        }
        return entityID;
    }


}
