package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.io.Serializable;

@Entity
//@Table(name="entityIndex")
public class Index implements Serializable{

    //the eID refers to type of entity
    //all stocks have same eID,etc
    private Long entityID;

    //name of the entity e.g. which bank stock or what type of crypto coin
    //entity name should be in the format: "<type> <name>"
    //where the type is : crypto,cash,stock
    //name is the name of the company/etc
    private String entityName;

    //uuid corresponds to the transaction unique id to map transactions
    //all transactions have different uuid
    @Id
    @GeneratedValue
    private Long id;


    private Long uuid;

    public Long getEntityID() {
        return entityID;
    }

    public void setEntityID(Long entityID) {
        this.entityID = entityID;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUuid() {
        return uuid;
    }

    public void setUuid(Long uuid) {
        this.uuid = uuid;
    }
}
